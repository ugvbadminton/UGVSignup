<?php
    if(!isset($_POST['submit'])){
        die('');
    }else{
        include("cn.php");
        //get field first name
        $first_name = $_POST['first_name'];
        $first_name = strip_tags($first_name);
        $first_name = addslashes($first_name);
        // get field last name
        $last_name = $_POST['last_name'];
        $last_name = strip_tags($last_name);
        $last_name = addslashes($last_name);
        // get field email address
        $email = $_POST['email'];
        $email = strip_tags($email);
        $email = addslashes($email);
        // get gender choice
        $gender = $_POST['gender'];
        $gender = strip_tags($gender);
        $gender = addslashes($gender);
        // get field phone number
        $phone = $_POST['phone'];
        $phone = strip_tags($phone);
        $phone = addslashes($phone);
        // get field student ID
        $sid = $_POST['sid'];
        $sid = strip_tags($sid);
        $sid = addslashes($sid);
        // field facebook name
        $fbn = $_POST['fbn'];
        $fbn = strip_tags($fbn);
        $fbn = addslashes($fbn);
        // get occupation
        $oc = $_POST['oc'];
        $oc = strip_tags($oc);
        $oc = addslashes($oc);
        // get field school
        $school = $_POST['school'];
        $school = strip_tags($school);
        $school = addslashes($school);
        // get field major
        $Major = $_POST['Major'];
        $Major = strip_tags($Major);
        $Major = addslashes($Major);
        // get field company
        $com = $_POST['com'];
        $com = strip_tags($com);
        $com = addslashes($com);
        // get sign up as
        $Sua = $_POST['Sua'];
        $Sua = strip_tags($Sua);
        $Sua = addslashes($Sua);
        // insert query
        $sql = "insert into member(first_name,last_name,email,gender,phone,sid,fbn,oc,school,major,com,sua) values('$first_name','$last_name','$email','$gender','$phone','$sid','$fbn','$oc','$school','$Major','$com','$Sua')";
        mysql_query($sql);
        echo 'Add complete';
        mysql_close();
    }
?>