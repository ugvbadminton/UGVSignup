<?php
    $host = "localhost";
    $username = "ezybycom_ugv";
    $password = "Hoanhanh09";
    $dbname = "ezybycom_ugv";
    $dbtable = "member";
    mysql_connect("$host","$username","$password")or die("Cannot connect");
    mysql_select_db("$dbname")or die("Cannot choose database");
?>